birthday = (4, 12, 1991)

# print(len(birthday))

# print(birthday[0])
# print(birthday[1])
# print(birthday[2])

# print(birthday[15])

# print(birthday[-1])
# print(birthday[-2])
# print(birthday[-3])
# print(birthday[-4])

# birthday[1] = 13

addresses = (
    ['Hudson Street', 'New York', 'NY'],
    ['Franklin Street', 'San Francisco', 'CA']
)

addresses[1][0] = "Polk Street"
# print(addresses)

print(dir(birthday))