# x = 10

def change_stuff():
    global x
    x = 15

# print(x)
change_stuff()
print(x)