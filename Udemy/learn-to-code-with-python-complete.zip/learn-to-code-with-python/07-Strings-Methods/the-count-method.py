word = "queueing"

print(word.count("e"))
print(word.count("u"))
print(word.count("q"))
print(word.count("z"))
print(word.count("Q"))

print(word.count("ue"))
print(word.count("ing"))
print(word.count("u") + word.count("e"))