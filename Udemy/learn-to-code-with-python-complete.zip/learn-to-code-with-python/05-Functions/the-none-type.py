a = None
print(type(a))

def subtract(a, b):
    print(a - b)

result = subtract(5, 3)
print(result)