def add(a = 0, b = 0):
    return a + b

print(add(7, 8))
print(add(10))
print(add())