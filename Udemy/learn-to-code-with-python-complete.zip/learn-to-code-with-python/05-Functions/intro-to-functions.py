def output_text():
    print("Welcome to the program!")
    print("It's nice to meet you")
    print("Have an excellent day programming!")

output_text()
output_text()