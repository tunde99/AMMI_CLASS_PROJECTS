def add(a, b):
    return a + b
    print("This is nonsense")

result = add(3, 5)
print(result)