def p(text):
    print(text)

p("Hello")
p("Goodbye")
p("OK")

# p()

def add(a, b):
    print("The sum of", a, "and", b, "is", a + b)

add(3, 5)
add(-4, 7)

# add()
# add(1)
add(3, 5, 7)