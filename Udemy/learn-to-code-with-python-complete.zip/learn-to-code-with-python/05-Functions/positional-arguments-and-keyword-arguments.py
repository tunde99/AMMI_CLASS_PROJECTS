def add(a, b, c):
  print("The sum of the three numbers is", a + b + c)

add(5, 10, 15)
add(a = 5, b = 10, c = 15)
add(5, b = 10, c = 15)
add(5, c = 15, b = 10)