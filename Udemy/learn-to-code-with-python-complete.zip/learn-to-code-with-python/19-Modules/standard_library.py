import string
import math
import this

# print(string.ascii_letters)
# print(string.ascii_lowercase)
# print(string.ascii_uppercase)
# print(string.digits)
# print(string.capwords("hello there"))

# print(math.ceil(4.5))
# print(math.floor(4.8))
# print(math.sqrt(9))
# print(math.sqrt(32))
# print(math.pi) 