"sushi"
'sushi'
"warriorsfan123!"
"$5.00"

"You're right"
'Shakespeare once wrote "To be or not to be" in one of his plays'

" "
""
''

"5"
5

"""Hello
my name is
Boris
"""