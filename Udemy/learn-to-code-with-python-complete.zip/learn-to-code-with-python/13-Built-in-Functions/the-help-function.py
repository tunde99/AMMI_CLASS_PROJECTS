# help(len)
# help(print)
# help("len")
# help("print")

# help(str)
# help(int)
# help(list)

# help("Hello".replace)
# help("mystery".swapcase)
help([1].extend)