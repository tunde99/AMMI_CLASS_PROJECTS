nintendo_games = ["Zelda", "Mario", "Donkey Kong", "Zelda"]

nintendo_games.remove("Zelda")
print(nintendo_games)

nintendo_games.remove("Zelda")
print(nintendo_games)

if "Wario" in nintendo_games:
    nintendo_games.remove("Wario")

if "Mario" in nintendo_games:
    nintendo_games.remove("Mario")

print(nintendo_games) 