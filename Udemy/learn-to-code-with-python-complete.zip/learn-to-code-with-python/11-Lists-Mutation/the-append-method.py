countries = ["United States", "Canada", "Australia"]
print(countries)
print(len(countries))

countries.append("Japan")
print(countries)
print(len(countries))

countries.append("France")
print(countries)
print(len(countries))

countries.append("Belgium")
print(countries)
