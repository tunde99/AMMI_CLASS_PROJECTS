print(15 / 3)
print(14 / 3)

print(14 // 3)
print(-14 // 3)

print(14 % 3)
print(15 % 3)
print(16 % 3)

print(1 % 3)
print(2 % 3)
print(3 % 3)