print(3 + 4)
print(3.5 + 6.3)
print(10 - 5)
print(5 * 3)

print("Ba" + "con")
print("lolo" * 32)

print(10 + 3.8)

print(5 ** 3)
print(4 ** 4)

print(3 + 5 * 3)
print((3 + 5) * 3)