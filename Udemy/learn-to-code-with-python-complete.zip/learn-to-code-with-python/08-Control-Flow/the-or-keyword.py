if 5 > 8 or 7 < 11:
    print("At least one of the conditions is True!")

if "cat" == "cat" or "dog" == "donkey":
    print("At least one of the conditions is True!")

if "cat" == "cat" or "dog" == "dog":
    print("At least one of the conditions is True!")

if "apple" == "banana" or "orange" == "pear":
    print("Will this print? Nope!")
