if 5 > 3:
    print("Yup, that's true. This will be printed!")
    print("Here's another line! Hooray")

if 6 > 10:
    print("Nope, that is FALSE. That will not be printed!")

if "boris" == "boris":
    print("Great name!")

if "dave" == "Dave":
    print("Awesome name")

if "dave" != "Dave":
    print("Haha, got you to print")
    print("Great success!")

if True:
    print("Always true, always prints")

if False:
    print("Never true, not fit to print!")