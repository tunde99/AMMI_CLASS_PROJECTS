import unittest

class TestStringMethods(unittest.TestCase):
    def test_split(self):
        pass

if __name__ == "__main__":
    unittest.main()